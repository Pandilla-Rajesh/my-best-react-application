import axios from 'axios'
import React, { useEffect, useState } from 'react'

function UseCustomAPI(url){

    const [user, setUser] = useState([])

    useEffect(()=>{

        axios.get(url).then((res)=>{
            setUser(res.data)
            console.log(res.data.slice(0,10))
        })
    }, [user])


    return {user}

}

export default UseCustomAPI