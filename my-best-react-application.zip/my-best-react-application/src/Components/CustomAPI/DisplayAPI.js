import React from 'react'
import UseCustomAPI from './UseCustomAPI'
import { Col, Container, Row, Table } from 'react-bootstrap'

const DisplayAPI = () => {

    const url = 'https://jsonplaceholder.typicode.com/posts'
    const {user} = UseCustomAPI(url)
    const headers = user && user.length > 0 ? Object.keys(user[0]) : []

    return (

        <Container>
            <Row>

                <Col lg={12} className='mt-5 p-5'>
                    <h1 className='text-center'>use custom API Integartion <br />with table data display</h1>
                </Col>

                <Table responsive bordered>
                    <thead>
                        <tr>
                            {headers.map((list)=>(
                                <th>{list}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {user.length > 0 ? user.slice(0,10)?.map((item, index)=>(
                           
                            <tr key={index}>
                                <td>{item.userId}</td>
                                <td>{item.id}</td>
                                <td>{item.title}</td>
                                <td>{item.body}</td>
                            </tr>

                        )):(
                            
                            <Col lg={12}>
                                <p>No Data Found</p>
                            </Col>
                        )}
                    </tbody>
                </Table>
            </Row>
        </Container>

    )

}

export default DisplayAPI