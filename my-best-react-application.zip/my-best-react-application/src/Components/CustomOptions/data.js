import React from 'react'
export const items = Array.from({ length: 100 }, (_, index) => ({
    id: index + 0,
    name: `Data ${index + 0}`,
  }));
const data = () => {
    
  return (
    <div>
      ffff
    </div>
  )
}

export default data
