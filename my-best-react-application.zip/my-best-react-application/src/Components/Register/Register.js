import React, { useState } from "react";
import { Button, Col, Container, Form, FormControl, FormGroup, FormLabel, Row } from "react-bootstrap";
import ReactMemo from "../CommonComp/ReactMemo";

const Register=()=>{
    
 const [reglist, setRegList] = useState({
    fname:'',
    lname:'',
    email:'',
    phone:'',
    address:'',
    country:''
 })

const handleChange=(event)=>{
    const {name, value} = event.target
    setRegList({...reglist, [name]: value})
}

const [error, setError] = useState({})

const handleSubmit=(e)=>{
    e.preventDefault()
    const errors={}
    
    if(!reglist.fname.trim()){
        errors.fname = 'please enter name'
    }

    if(!reglist.lname.trim()){
        errors.lname = 'Please enter password'
    }

    if(!reglist.email.trim()){
        errors.email = 'Please enter email'
    }

    if(Object.keys(errors).length == 0){
        console.log(reglist, 'reg list data')
    }else{
        setError(errors)
    }
    console.log(reglist, 'data received register data')
}

    return(
        <>
          <Container>
                <Form onSubmit={handleSubmit}>
                    <Row>
                        <Col lg={4} className="mb-3">
                            <FormGroup>
                                <FormLabel>
                                    First Name
                                </FormLabel>
                                <FormControl onChange={handleChange} />
                            </FormGroup>
                        </Col>
                        <Col lg={8}>
                            <ReactMemo/>
                        </Col>
                    </Row>
                </Form>
          </Container>
        </>
    )
}

export default Register