import React from 'react'
import Parent from './Parent'

function Props(){
    return(
        <>
        <Parent/>
        </>
    )
}

export default Props